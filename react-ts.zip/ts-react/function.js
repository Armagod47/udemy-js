// let drawPoint = (point: { x: number; y: number }) => {
//   return point;
// };
// drawPoint({
//   x: 10,
//   y: 20,
// });
// Interface
// interface Point {
//   x: number;
//   y: number;
//   draw: () => void;
// }
// Violating interface definition
// let drawPoint = (point: Point) => {
//   return point;
// };
// drawPoint({
//   x: 10,
//   y: 20,
// });
// Class
// class Point {
//   x: number;
//   y: number;
//   draw() {
//     console.log("X:" + this.x + "Y:" + this.y);
//   }
// }
// let point = new Point();
// point.x = 1;
// point.y = 2;
// point.draw();
// Constructor
var Point = /** @class */ (function () {
    function Point(x, y) {
        this.x = x;
        this.y = y;
    }
    Point.prototype.draw = function () {
        console.log("X:" + this.x + "Y:" + this.y);
    };
    return Point;
}());
var point = new Point(1, 2);
point.draw();
