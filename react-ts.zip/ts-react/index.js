// let msg = "abc";
// let s = msg.endsWith("c");
// type assertion
var message;
message = "abc";
// let endsWithC = (<string>message).endsWith("c");
var endsWithCAlt = message.endsWith("c");
