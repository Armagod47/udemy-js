// let drawPoint = (point: { x: number; y: number }) => {
//   return point;
// };

// drawPoint({
//   x: 10,
//   y: 20,
// });

// Interface
// interface Point {
//   x: number;
//   y: number;
//   draw: () => void;
// }

// Violating interface definition
// let drawPoint = (point: Point) => {
//   return point;
// };

// drawPoint({
//   x: 10,
//   y: 20,
// });

// Class
// class Point {
//   x: number;
//   y: number;
//   draw() {
//     console.log("X:" + this.x + "Y:" + this.y);
//   }
// }

// let point = new Point();
// point.x = 1;
// point.y = 2;
// point.draw();

// Constructor
// class Point {
//   private x: number;
//   private y: number;

//   constructor(x: number, y: number) {
//     this.x = x;
//     this.y = y;
//   }
//   draw() {
//     console.log("X: " + this.x + " Y: " + this.y);
//   }
// }

// let point = new Point(1, 3);
// point.draw();

// without this keyword
// class Point {
//   constructor(private x: number, private y: number) {}
//   draw() {
//     console.log("X: " + this.x + " Y: " + this.y);
//   }
// }

// let point = new Point(1, 3);
// point.draw();

// Properties
// class Point {
//   constructor(private _x: number, private _y: number) {}
//   draw() {
//     console.log("X: " + this._x + " Y: " + this._y);
//   }
//   //   getX() {
//   //     return this.x;
//   //   }
//   //   setX(value) {
//   //     if (value < 0) {
//   //       throw new Error("alue Should be > 0");
//   //     }
//   //   }

//   get x() {
//     return this._x;
//   }
//   set x(value) {
//     if (value < 0) {
//       throw new Error("alue Should be > 0");
//     }
//   }
// }

// let point = new Point(1, 3);
// let x = point.x;
// point.draw();
// point.x = 100;

// Module Example
import { Point } from "./point";

let point = new Point(1, 2);
point.draw();
