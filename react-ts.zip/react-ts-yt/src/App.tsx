import React from "react";
import Greet from "./components/Greet";
import Person from "./components/Person";
import PersonsList from "./components/PersonsList";
import "./App.css";
import Status from "./components/Status";
import Headers from "./components/Headers";
import Oscars from "./components/Oscars";
import Buttons from "./components/event_props/Buttons";
import Inputs from "./components/event_props/Inputs";
import Container from "./components/style_props/Container";
import LoggedIn from "./components/states/LoggedIn";
import User from "./components/states/User";
import Reducer from "./components/states/Reducer";
import Box from "./components/usecontext/Box";
import { ThemeContextProvider } from "./components/usecontext/ThemeContext";
import FutureContextValue from "./components/usecontext/FutureContextValue";
import { UserContextProvider } from "./components/usecontext/FutureContext";
import DomRef from "./components/refs/DomRef";
import MutableRef from "./components/refs/MutableRef";
import { Counter } from "./components/class/Counter";
import Private from "./components/auth/Private";
import Profile from "./components/auth/Profile";
import List from "./components/generics/List";
import RandomNumber from "./components/restrictions/RandomNumber";
import Toast from "./components/templateliterals/Toast";
import Button from "./components/html/Button";
import CustomComponent from "./components/html/CustomComponent";
import Test from "./components/polymorphic/Test";
function App() {
  // Object Typing
  const PersonName = {
    first: "Bruce",
    last: "Wayne",
  };

  // Array Object Typing
  const PersonList = [
    { first: "Hugh", last: "Jackman" },
    { first: "Ryan", last: "Reynolds" },
    { first: "Bruce", last: "Wayne" },
  ];
  return (
    <div className="App">
      {/* we want Test comp to render based on as properties */}
      <Test as="h1" size="l">
        My Size is : L
      </Test>
      <Test as="p" size="m">
        My Size is : M
      </Test>
      <Test as="label" htmlFor="someID" size="l" color="black">
        My Size is : L
      </Test>
      <CustomComponent name="Himan" msgCount={100} />
      <Button variant="primary" onClick={() => console.log("Clicked")}>
        Primary
      </Button>
      <Toast position="center" />
      {/* while sending value and isPositiv props user can also send isNegative and isZero props to solve this issue we use props restriction */}
      <RandomNumber value={10} isPositive={true} />

      {/* Example of non restricitng props */}
      {/* <RandomNumber value={10} isPositive={true} isNegative isZero/> */}
      {/* <List
        items={["Batman", "Superman", "Wonder Woman"]}
        onClick={(listItemPara) => console.log(listItemPara)}
      />
      <List
        items={[1, 2, 3, 4, 5]}
        onClick={(listItemPara) => console.log(listItemPara)}
      /> */}
      <List
        items={[
          { id: 1, fname: "Himan", lname: "Boro" },
          { id: 2, fname: "Sindhu", lname: "Dara" },
          { id: 3, fname: "Rocky", lname: "Bhai" },
        ]}
        onClick={(listItemPara) => console.log(listItemPara)}
      />

      <Private isLoggedIn={true} component={Profile} />
      <Counter message="Hello World!!!" />
      <MutableRef></MutableRef>
      <DomRef></DomRef>
      <UserContextProvider>
        <FutureContextValue />
      </UserContextProvider>
      <ThemeContextProvider>
        <Box></Box>
      </ThemeContextProvider>
      <Reducer />
      <User></User>
      <LoggedIn />
      <Greet name="Boro" msgCount={12} isLoggedIn={false} />
      <Person name={PersonName} />
      <PersonsList list={PersonList} />
      <Status status="error" />
      <Headers>Some Text Passed From Parents As Children to Components</Headers>
      {/* Passing React component as child to other component */}
      <Oscars>
        <Headers>
          Some Text Passed From Parents As Children to Components
        </Headers>
      </Oscars>
      {/* Optional props */}
      <Greet name="Himan" msgCount={100} />
      <Buttons
        handleClick={(e, id) => console.log("Button Clicked", e, id)}
      ></Buttons>
      <Inputs value="" handleChange={(event) => console.log(event)}></Inputs>
      <Container
        styles={{ border: "5px solid white", padding: "1rem" }}
      ></Container>
    </div>
  );
}

export default App;
