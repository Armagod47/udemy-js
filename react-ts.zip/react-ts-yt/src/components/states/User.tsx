// import React, { useState } from "react";

// type AuthUser = {
//   name: string;
//   email: string;
// };

// function User() {
//   const [user, setUser] = useState<null | AuthUser>(null);
//   const loginHandle = () => {
//     setUser({
//       name: "Himan",
//       email: "xyz@gmail.com",
//     });
//   };
//   const logoutHandle = () => {
//     setUser(null);
//   };
//   return (
//     <div className="cards">
//       <button onClick={loginHandle}>Login</button>
//       <button onClick={logoutHandle}>LogOut</button>
//       {user ? (
//         <div>
//           Username is {user?.name} and Email ID is : {user?.email}
//         </div>
//       ) : (
//         <p>"Logged Out"</p>
//       )}
//     </div>
//   );
// }

// export default User;

// Type Assertion
import React, { useState } from "react";

type AuthUser = {
  name: string;
  email: string;
};

function User() {
  // Before when, we have set the default value of useState to null,
  // in that case we had to always check , the user value is not null before accessing the property
  const [user, setUser] = useState<AuthUser>({} as AuthUser);
  const loginHandle = () => {
    setUser({
      name: "Himan",
      email: "xyz@gmail.com",
    });
  };

  return (
    <div className="cards">
      <h4>UseState : Future value of useState</h4>
      <button onClick={loginHandle}>Login</button>

      {user ? (
        <div>
          Username is {user.name} and Email ID is : {user.email}
        </div>
      ) : (
        <p>"Logged Out"</p>
      )}
    </div>
  );
}

export default User;
