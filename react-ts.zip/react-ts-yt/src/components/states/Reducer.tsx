import React, { useReducer } from "react";
type CounterState = {
  count: number;
};

// Discriminated unions , used for usereducer

type UpdateAction = {
  type: "INCREASE" | "DECREASE";
  payload: number;
};

type ResetAction = {
  type: "RESET";
};

type CounterAction = UpdateAction | ResetAction;

const reducerFn = (state: CounterState, action: CounterAction) => {
  switch (action.type) {
    case "INCREASE":
      return { count: state.count + action.payload };
    case "DECREASE":
      return { count: state.count - action.payload };
    case "RESET":
      //   return { count: 0 };
      return initialState;
    default:
      return state;
  }
};

const initialState = { count: 0 };

function Reducer() {
  const [state, dispatch] = useReducer(reducerFn, initialState);
  const increaseHandler = () => {
    dispatch({ type: "INCREASE", payload: 10 });
  };
  const decreaseHandler = () => {
    dispatch({ type: "DECREASE", payload: 10 });
  };
  const resetHandler = () => {
    dispatch({ type: "RESET" });
  };
  return (
    <div className="cards">
      <h4>UseReducer</h4>
      {state.count}
      <button onClick={increaseHandler}>Increase</button>
      <button onClick={decreaseHandler}>Decrease</button>
      <button onClick={resetHandler}>RESET</button>
    </div>
  );
}

export default Reducer;
