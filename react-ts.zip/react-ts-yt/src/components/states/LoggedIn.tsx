import React, { useState } from "react";

function LoggedIn() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const loginHandle = () => {
    setIsLoggedIn(true);
  };
  const logoutHandle = () => {
    setIsLoggedIn(false);
  };
  return (
    <div className="cards">
      <h4>UseState : Default value of useState</h4>
      <button onClick={loginHandle}>Login</button>
      <button onClick={logoutHandle}>Logout</button>
      <h2>User is {isLoggedIn ? "Logged In" : "Logged Out"}</h2>
    </div>
  );
}

export default LoggedIn;
