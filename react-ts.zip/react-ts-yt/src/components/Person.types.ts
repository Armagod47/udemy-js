// typing object
// export type PersonProps = {
//   // name key should be equal to props name in parents
//   name: {
//     first: string;
//     last: String;
//   };
// };

// We cn also export types
export type Names = {
  first: string;
  last: String;
};

export type PersonProps = {
  name: Names;
};
