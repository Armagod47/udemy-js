import React from "react";
import Greet from "../Greet";

function CustomComponent(props: React.ComponentProps<typeof Greet>) {
  return (
    <div className="cards">
      <h3>
        Extracting Props from Other Components, eg from greet comp we will
        extract here
      </h3>
      <p>{props.isLoggedIn}</p>
      {props.msgCount}
      {props.name}
    </div>
  );
}

export default CustomComponent;
