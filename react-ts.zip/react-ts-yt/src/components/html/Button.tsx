import React from "react";
import Input from "./Input";
// Omit is used so that instead of sending html elements like div and all from PArent comp to buttoon comp, we typed it to send only string values
type ButtonProps = {
  variant: "primary" | "secondary";
  children: string;
} & Omit<React.ComponentProps<"button">, "children">;

function Button({ variant, children, ...rest }: ButtonProps) {
  return (
    <div className="cards">
      <h3>Wrapping HTML Elements</h3>
      <button className={`class-with-${variant}`} {...rest}>
        {children}
      </button>
      <Input type="number"></Input>
    </div>
  );
}

export default Button;
