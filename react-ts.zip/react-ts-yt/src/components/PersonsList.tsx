import React from "react";
import "../index.css";
import { Names } from "./Person.types";
// type ListProps = {
//   // declaring array object type names: {...}[]
//   // list key name should be equal to props name in parents
//   list: {
//     first: string;
//     last: string;
//   }[];
// };

// importing types
type ListProps = {
  list: Names[];
};

export default function PersonsList(props: ListProps) {
  return (
    <div className="cards">
      <h3>
        {props.list.map((name) => {
          return (
            <p key={name.first}>
              {name.first} {name.last}
            </p>
          );
        })}
      </h3>
    </div>
  );
}
