import React from "react";

type TextOwnProps<E extends React.ElementType> = {
  size?: "s" | "m" | "l";
  color?: "red" | "black";
  children: React.ReactNode;
  as?: E;
};

type TextProps<E extends React.ElementType> = TextOwnProps<E> &
  Omit<React.ComponentProps<E>, keyof TextOwnProps<E>>;
const Test = <E extends React.ElementType = "div">({
  size,
  color,
  children,
  as,
}: TextProps<E>) => {
  const Component = as || "div";
  return (
    <div className="cards">
      <h2>Polymorphic Props</h2>
      <Component className={`class-with-${size}-${color}`}>
        {children}
      </Component>
    </div>
  );
};

export default Test;
