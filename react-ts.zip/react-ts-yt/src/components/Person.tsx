import React from "react";
import "../index.css";
import { PersonProps } from "./Person.types";
// // typing object
// type PersonProps = {
//   // name key should be equal to props name in parents
//   name: {
//     first: string;
//     last: String;
//   };
// };
export default function Person(props: PersonProps) {
  return (
    <div className="cards">
      <h1>
        {props.name.first} {props.name.last}
      </h1>
    </div>
  );
}
