import React from "react";
import "../index.css";
type HeadersProps = {
  children: string;
};
// Passing children from parents , into child component
function Headers(props: HeadersProps) {
  return <div className="cards">{props.children}</div>;
}

export default Headers;
