import React from "react";
import "../../index.css";
type StyleProps = {
  styles: React.CSSProperties;
};

function Container(props: StyleProps) {
  return (
    <div className="cards">
      <div style={{ border: "5px solid red", padding: "1rem" }}>Text Here</div>
      <div style={props.styles}>Second Text Here</div>
    </div>
  );
}

export default Container;
