import React from "react";

type Horizontal = "left" | "center" | "right";
type Vertical = "top" | "center" | "bottom";

type ToastProps = {
  //   position: `${Horizontal}-${Vertical}`;
  position: Exclude<`${Horizontal}-${Vertical}`, "center-center"> | "center";
};

function Toast({ position }: ToastProps) {
  return <div className="cards">Toast Notification Position - {position}</div>;
}

export default Toast;
