// import React from "react";

// type ListProps = {
//   items: string[] | number[];
//   onClick: (value: string | number) => void;
// };

// function List({ items, onClick }: ListProps) {
//   return (
//     <div className="cards">
//       <h2>Generics</h2>
//       <h2>List Of Items</h2>
//       {items.map((itemx, index) => {
//         return (
//           <li key={index} onClick={() => onClick(itemx)}>
//             {itemx}
//           </li>
//         );
//       })}
//     </div>
//   );
// }

// export default List;

// import React from "react";

// Generic Example
// wITH GENERIC NOW WE CAN PASS ANY ARRAY OF OBJECT/STRING/NUMBER
type ListProps<T> = {
  items: T[];
  onClick: (value: T) => void;
};

// Constraining
// const List = <T extends string | number>({ items, onClick }: ListProps<T>) => {
const List = <T extends { id: number }>({ items, onClick }: ListProps<T>) => {
  // const List = <T extends {}>({ items, onClick }: ListProps<T>) => {
  return (
    <div className="cards">
      <h2>Generics</h2>
      <h2>List Of Items</h2>
      {items.map((itemx, index) => {
        return (
          <div key={itemx.id} onClick={() => onClick(itemx)}>
            {JSON.stringify(itemx)}
          </div>
        );
      })}
    </div>
  );
};

export default List;
