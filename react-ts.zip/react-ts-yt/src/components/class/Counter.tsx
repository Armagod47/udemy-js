import { Component } from "react";

type CounterProps = {
  message: string;
};
type CounterState = {
  count: number;
};

// Props Type should come first followed by State Type
// if no props is there than use <{}, StateType>
// if props is there and no state is there than use, <PropsType>
export class Counter extends Component<CounterProps, CounterState> {
  state = {
    count: 0,
  };

  handleClick = () => {
    this.setState((prevState) => ({ count: prevState.count + 1 }));
  };

  render() {
    return (
      <div className="cards">
        <h3>This Is Class Component</h3>
        <button onClick={this.handleClick}>Increment</button>
        {this.props.message} {this.state.count}
      </div>
    );
  }
}
