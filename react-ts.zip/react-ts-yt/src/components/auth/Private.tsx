import React from "react";
import Login from "./Login";
import { ProfileProps } from "./Profile";
type PrivateProps = {
  isLoggedIn: boolean;
  // Type for React Component,ProfileProps is used because Component passed as props also takes pros itsef, name props in these eg
  component: React.ComponentType<ProfileProps>;
};

function Private({ isLoggedIn, component: Component }: PrivateProps) {
  if (isLoggedIn) {
    return <Component name="Himan"></Component>;
  } else {
    return <Login />;
  }
}

export default Private;
