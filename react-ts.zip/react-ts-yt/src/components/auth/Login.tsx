import React from "react";

type Props = {};

function Login({}: Props) {
  return <div>Please Login To Continue</div>;
}

export default Login;
