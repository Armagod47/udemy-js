import React, { useEffect, useRef } from "react";

function DomRef() {
  // for dom references specify HTML/DOM element type
  const inputRef = useRef<HTMLInputElement>(null!);

  useEffect(() => {
    inputRef.current.focus();
  }, []);
  return (
    <div className="cards">
      <h2>useRef : DOM Ref Example</h2>
      <input type="text" ref={inputRef} />
    </div>
  );
}

export default DomRef;
