import { useState, useRef } from "react";

function MutableRef() {
  const [timer, setTimer] = useState(0);
  // for mutable references specify appropriate type. eg number in settimeout or setinterval
  const interValRef = useRef<number | null>(null);

  const stopTimer = () => {
    if (interValRef.current) {
      window.clearInterval(interValRef.current);
    }
  };

  // useEffect(() => {
  //   interValRef.current = window.setInterval(() => {
  //     setTimer((timer) => timer + 1);
  //   }, 1000);
  //   return () => {
  //     stopTimer();
  //   };
  // }, []);
  return (
    <div className="cards">
      <h2>useRef : Mutable Ref Example</h2>
      HookTimer - {timer} -<button onClick={stopTimer}>Stop Timer</button>
    </div>
  );
}

export default MutableRef;
