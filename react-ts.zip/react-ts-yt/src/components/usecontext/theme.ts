export const theme = {
  primary: {
    main: "red",
    text: "white",
  },
  secondary: {
    main: "blue",
    text: "#000",
  },
};
