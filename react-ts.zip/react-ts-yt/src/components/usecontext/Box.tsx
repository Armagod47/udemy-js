import React, { useContext } from "react";
import { ThemeContext } from "./ThemeContext";

function Box() {
  const theme = useContext(ThemeContext);
  return (
    <div
      className="cards"
      style={{ backgroundColor: theme.primary.main, color: theme.primary.text }}
    >
      <h2>UseContext Example</h2>
      <p>Content Here</p>
    </div>
  );
}

export default Box;
