import React, { useContext } from "react";
import { UserContext } from "./FutureContext";

function FutureContextValue() {
  const userCtx = useContext(UserContext);
  const loginHandle = () => {
    userCtx.setUser({
      name: "Himan",
      email: "xuza@gmail.com",
    });
  };
  const logoutHandle = () => {
    userCtx.setUser(null);
  };
  return (
    <div className="cards">
      <h3>
        useContext where createcontext value will be provided by user in fututre
      </h3>
      <button onClick={loginHandle}>Login</button>
      <button onClick={logoutHandle}>Logout</button>
      <h3>User Name is : {userCtx.user?.name}</h3>
      <h3>Email is : {userCtx.user?.email}</h3>
    </div>
  );
}

export default FutureContextValue;
