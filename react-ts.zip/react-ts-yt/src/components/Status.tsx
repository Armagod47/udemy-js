import React from "react";
import "../index.css";
type StatusProps = {
  status: "loading" | "success" | "error";
};
function Status(props: StatusProps) {
  let msg: string;
  if (props.status === "loading") {
    msg = "Loading...";
  } else if (props.status === "success") {
    msg = "Successfull";
  } else {
    msg = "Error!!!";
  }
  return (
    <div className="cards">
      <h2>Status - {msg}</h2>
    </div>
  );
}

export default Status;
