import React from "react";
import "../index.css";
// Use types when building applications and Interfaces when building library
type GreetProps = {
  name: string;
  msgCount: number;
  // Optional Props
  isLoggedIn?: boolean;
};

export default function Greet(props: GreetProps) {
  // Setting default value to 0, if optional props is passed
  // const { isLoggedIn = false } = props;
  return (
    <div className="cards">
      {props.isLoggedIn ? (
        `Hi ${props.name}You Have ${props.msgCount} missed notificaitons`
      ) : (
        <h1>Welcome Guest!!!</h1>
      )}
    </div>
  );
}
