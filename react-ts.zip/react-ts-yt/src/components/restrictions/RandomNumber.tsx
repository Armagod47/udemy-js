import React from "react";
// Props Restriction
type RandomNumberType = {
  value: number;
};

type PositiveNumber = RandomNumberType & {
  isPositive: boolean;
  isNegative?: never;
  isZero?: never;
};

type NegativeNumber = RandomNumberType & {
  isPositive?: never;
  isNegative: boolean;
  isZero?: never;
};
type Zero = RandomNumberType & {
  isZero: boolean;
  isPositive?: never;
  isNegative?: never;
};
// Props Restriction
type RandomNumberProps = PositiveNumber | NegativeNumber | Zero;
function RandomNumber({
  value,
  isPositive,
  isNegative,
  isZero,
}: RandomNumberProps) {
  return (
    <div className="cards">
      <h3>Restriciting Props</h3>
      <p>{value}</p>
      <p>{isPositive && "Positive Number"}</p>
      <p>{isNegative && "Negative Number"}</p>
      <p>{isZero && "Zero Number"}</p>
    </div>
  );
}

export default RandomNumber;

// Old Example
// type RandomNumberProps = {
//     value: number;
//     isPositive?: boolean;
//     isNegative?: boolean;
//     isZero?: boolean;
//   };
//   function RandomNumber({
//     value,
//     isPositive,
//     isNegative,
//     isZero,
//   }: RandomNumberProps) {
//     return (
//       <div className="cards">
//         <h3>Restriciting Props</h3>
//         <p>{value}</p>
//         <p>{isPositive && "Positive Number"}</p>
//         <p>{isNegative && "Negative Number"}</p>
//         <p>{isZero && "Zero Number"}</p>
//       </div>
//     );
//   }

//   export default RandomNumber;
