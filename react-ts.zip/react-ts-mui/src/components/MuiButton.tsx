import React, { useState } from "react";
import {
  Button,
  Stack,
  IconButton,
  ButtonGroup,
  ToggleButton,
  ToggleButtonGroup,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import FormatBoldIcon from "@mui/icons-material/FormatBold";
import FormatItalicIcon from "@mui/icons-material/FormatItalic";
import FormatUnderlinedIcon from "@mui/icons-material/FormatUnderlined";
function MuiButton() {
  return (
    <Stack spacing={2} direction="row">
      <Stack spacing={2} direction="row">
        <Button variant="text" href="https://google.com">
          SUBMIT Text
        </Button>
        <Button variant="contained">SUBMIT Contained</Button>
        <Button variant="outlined">SUBMIT Outlined</Button>
      </Stack>
    </Stack>
  );
}

export default MuiButton;
