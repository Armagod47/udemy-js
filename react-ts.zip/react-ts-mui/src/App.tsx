import MuiTypography from "./components/MuiTypography";
import MuiButton from "./components/MuiButton";
import "./App.css";

function App() {
  return (
    <div className="App">
      <MuiButton />
      <MuiTypography />
    </div>
  );
}

export default App;
