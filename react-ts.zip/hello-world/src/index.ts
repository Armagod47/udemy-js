// let sales: number = 123_456_789;
// let course: string = "TypeScript";
// let is_published: boolean = true;

// We Can write without annotation as well
let sales = 123_456_789;
let course = "TypeScript";
let is_published = true;

// If we dont define any var, it will set to any type
let level;
level = 1;

// explicitly setting document to any type var
// function render(document: any) {
//   console.log(document);
// }

// we can turnoff "noImplicitAny": true in cnfig file to write below fn, but not recommended
// function render(document) {
//   console.log(document);
// }

// Array
let numbers = [1, 2, 3, 4, "5"];
let numberss: number[] = [2, 3, 4, 5];
// avoid any array
let numberx = [];

// Tupples
let user: [number, string] = [1, "Boro"];

// enums
// const small =1;
// const medium =2;
// const large =3;

// bydefault ts sets first value to 0, Small=0
const enum Size {
  Small = 1,
  Medium,
  Large,
}

let mySize: Size = Size.Medium;
console.log(mySize);
