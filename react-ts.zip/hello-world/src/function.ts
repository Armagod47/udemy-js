// Always anotate function
function calculateTax(income: number, taxYear: number): number {
  if (taxYear < 2022) {
    return income * 0.5;
  }

  return income * 1.5;
}

calculateTax(10_000, 2023);

// Passing default value
function calculateTaxs(income: number, taxYear = 2022): number {
  if (taxYear < 2022) {
    return income * 0.5;
  }

  return income * 1.5;
}

// Optional Argument
// function calculateTaxs(income: number, taxYear?: number): number {
//   if ((taxYear || 2022) < 2022) {
//     return income * 0.5;
//   }

//   return income * 1.5;
// }

// Function types
let ctx: (a: number, b: number) => number;
// Storing calculateTax in ctx
ctx = calculateTax;

// Callback
function addHandle(n1: number, n2: number, callBack: (num: number) => void) {
  const res = n1 + n2;
  callBack(res);
}

addHandle(10, 20, (result) => {
  console.log(result);
});
