// let emp: {
//   readonly id: number;
//   //   name?: string;
//   name: string;
//   retire: (date: Date) => void;
// } = {
//   id: 1,
//   name: "",
//   retire: (date: Date) => {
//     console.log(date);
//   },
// };

// Type Alias
type Employee = {
  readonly id: number;
  name: string;
  retire: (date: Date) => void;
};

let employee: Employee = {
  id: 1,
  name: "Himan",
  retire: (date: Date) => {
    console.log(date);
  },
};

// Union Type
// With union type we can give a fn parameter more than one type
//  | is union type
function kgToLbs(weight: number | string): number {
  // Narrowing
  if (typeof weight === "number") {
    // console.log(weight * 2.2);
    return weight * 2.2;
  } else {
    // console.log(parseInt(weight) * 2.2);
    return parseInt(weight) * 2.2;
  }
}

kgToLbs(10);
kgToLbs("50");

// Intesection type uses &

type Draggable = {
  drag: () => void;
};

type Resizeable = {
  resize: () => void;
};

type UIWidget = Draggable & Resizeable;

let textBox: UIWidget = {
  drag: () => {},
  resize: () => {},
};

// Literal types :if we want to limit the values, we can assign to a variable than use Literal types
// let quantity: 50 = 50;
// let quantitys: 50 | 100 = 100;

type Quantity = 50 | 100;
let quantity: Quantity = 100;

type Metric = "cm" | "mm";
let measurement: Metric = "cm";

// Nullable Types :
function greet(name: string | null | undefined) {
  if (name) {
    console.log(name.toUpperCase());
  } else {
    console.log("Hola");
  }
}

greet(null);

// Optional Chaining
type Customer = {
  bday: Date;
};

function getCustomer(id: number): Customer | null | undefined {
  return id === 0 ? null : { bday: new Date() };
}

let customer = getCustomer(0);
// if (customer !== null && customer !== undefined) {
//   console.log(customer.bday);
// }

// Optional propety access operator
// below will run only if customer is not null or undefined
console.log(customer?.bday);

// unknown : store any value. It is more restrictive than any
// If you dnt know exactly what type you will store in there it might me number or string, but you will figure out eventually than use unknown type
let userInput: unknown;
let userName: string;

userInput = 5;
userInput = "Max";

// cannot assign unknown type to string type
// userName = userInput;

// Assigning unknown type value to fixed type
// can assign unknown type to string type with typeof check
if (typeof userInput === "string") {
  userName = userInput;
}

// never
//these fn will crash the app so it will return never type
// other eg : infinite while loop
function genereteError(msg: string, code: number): never {
  throw { message: msg, eCode: code };
}

genereteError("An Error Occured", 404);
