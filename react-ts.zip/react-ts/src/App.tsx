import React, { FC, createContext } from "react";
import "./App.css";
import Persons from "./components/Persons";
import NewPersons from "./components/NewPersons";
import States, { HairColor } from "./components/States";
interface AppContextInterface {
  name: string;
  age: number;
  country: string;
}
const AppContext = createContext<AppContextInterface | null>(null);
const App: FC = () => {
  const contextValue: AppContextInterface = {
    name: "Himan",
    age: 20,
    country: "India",
  };
  return (
    <AppContext.Provider value={contextValue}>
      <div className="App">
        <Persons name="Himan" age={25} email="xyz@gmail.com" />
        <NewPersons name="Sindhu" age={23} email="sindhu@gmail.com" />
        <States
          name="Sindhu"
          age={23}
          email="sindhu@gmail.com"
          hairColor={HairColor.Blonde}
        />
      </div>
    </AppContext.Provider>
  );
};

export default App;
