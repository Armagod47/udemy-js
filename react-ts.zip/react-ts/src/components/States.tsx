// tsrfc
import React, { FC, useState, ChangeEvent } from "react";

export enum HairColor {
  Blonde = "Your Hair is blond, good for you",
  Brown = "Cool Hair color",
  BlackHighLight = "Looking Great",
}

interface Props {
  name: string;
  age: number;
  email: string;
  hairColor: HairColor;
}

const States: FC<Props> = ({ name, age, email, hairColor }) => {
  const [country, setCountry] = useState<string | null>("");
  const [home, setHome] = useState<string | null>("");
  const handleHome = (e: ChangeEvent<HTMLInputElement>) => {
    setHome(e.target.value);
  };
  //   type NameType = "Himan" | "Boro";
  //   const nameForType: NameType = "Boro";
  return (
    <div>
      <div>
        <h1>{name}</h1>
        <h2>{age}</h2>
        <h3>{email}</h3>
        <input
          type="text"
          placeholder="Name Your State..."
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setCountry(e.target.value)
          }
        />
        <p>{country}</p>
        <input type="text" placeholder="Hometown" onChange={handleHome} />
        <p>{home}</p>
      </div>
      {/* {HairColor.BlackHighLight} */}
      {hairColor}
    </div>
  );
};

export default States;
