import React, { FC } from "react";

interface Props {
  name: string;
  age: number;
  email: string;
  //   optional props
  siblings?: boolean;
  //   getName: (name: string) => string;
}

const NewPersons: FC<Props> = ({ name, age, email }) => {
  return (
    <div>
      <div>
        <h1>{name}</h1>
        <h2>{age}</h2>
        <h3>{email}</h3>
      </div>
    </div>
  );
};

export default NewPersons;
