import * as React from "react";

interface Props {
  name: string;
  age: number;
  email: string;
  //   optional props
  siblings?: boolean;
  //   getName: (name: string) => string;
}

// const Persons = (props: Props) => {
//   return (
//     <div>
//       <h1>{props.name}</h1>
//       <h2>{props.age}</h2>
//       <h3>{props.email}</h3>
//     </div>
//   );
// };

// second way to use props
const Persons = ({ name, email, age }: Props) => {
  return (
    <div>
      <h1>{name}</h1>
      <h2>{age}</h2>
      <h3>{email}</h3>
    </div>
  );
};
export default Persons;
