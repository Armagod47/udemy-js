import React from "react";
import { ITask } from "../Interface";
interface Props {
  task: ITask;
  removeTask(taskNameDel: string): void;
}
function ToDotask({ task, removeTask }: Props) {
  return (
    <div>
      {task.taskNames}
      {task.taskPrioritys}
      <button
        onClick={() => {
          removeTask(task.taskNames);
        }}
      >
        Remove
      </button>
    </div>
  );
}

export default ToDotask;
