export interface ITask {
  taskNames: string;
  taskPrioritys: number;
}
