import React, { ChangeEvent, FC, useState } from "react";
import { ITask } from "./Interface";
import ToDotask from "./components/ToDotask";
import "./App.css";

const App: FC = () => {
  const [task, setTask] = useState<string>("");
  const [priority, setPriority] = useState<number>(0);
  const [todo, setToDo] = useState<ITask[]>([]);
  const handleChange = (event: ChangeEvent<HTMLInputElement>): void => {
    if (event.target.name === "task") {
      setTask(event.target.value);
    }
    // setPriority(+event.target.value);
    setPriority(Number(event.target.value));
  };

  const addTask = (): void => {
    const newTask = { taskNames: task, taskPrioritys: priority };
    setToDo([...todo, newTask]);
    setTask("");
    setPriority(0);
  };

  const removeTask = (taskNameDel: string): void => {
    setToDo(
      todo.filter((tasks) => {
        return tasks.taskNames !== taskNameDel;
      })
    );
  };
  return (
    <div className="App">
      <div className="header">
        <div className="inputContainer">
          <input
            type="text"
            placeholder="Add Task..."
            onChange={handleChange}
            name="task"
            value={task}
          />
          <input
            type="number"
            placeholder="Priority"
            onChange={handleChange}
            name="priority"
            value={priority}
          />
        </div>
        <button onClick={addTask}>Add</button>
      </div>
      <div className="todoList">
        {todo.map((task: ITask, key: number) => {
          return <ToDotask key={key} task={task} removeTask={removeTask} />;
        })}
      </div>
    </div>
  );
};

export default App;
