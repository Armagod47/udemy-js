const n: number = 10;

console.log(n);
