const getPaymentDetails = (paymentMethodDetailsResponse, paymentMethods) => {
    const INTERNAL_TOKEN = {
        PENAVIGATION: "PE",
        FINANCE: "FINANCE",
        PO: "PO",
        SO: "SO",
        CYBERSOURCE: "CYBERSOURCE",
        CC2C2P: "CC2C2P",
        BT2C2P: "BT2C2P",
        OFFLINE: "OFF",
        AFFIRM: "AFFIRM",
        QUOTE: "QUOTE"
    };
    
    const ORDER_PAYMENT_MODE = {
            PE_Card: 'CARD',
            PE_Account: 'ACCOUNT',
            PE_PurchaseOrder: 'PURCHASE_ORDER',
            PE_NetBanking: 'NET_BANKING',
            PE_Key: 'Key',
            PE_Boleto: 'BOLETO',
            PE_FinanceOption: 'AFFIRM',
            PE_VirtualAccount: 'VIRTUAL_ACCOUNT',
            PE_SepaDirectDebit: 'SEPA_DIRECT_DEBIT',
            PE_Klarna: 'KLARNA'
    }
    const HYBRISPAYMENT_ATTRIBUTE = {
        ACCOUNTTYPE : 'accountType',
        PAYMENTMETHOD : 'paymentMethod',
    };
    let paymentDetailsValue;
    let emiDescriptionField;
    let accountOrPaymentType = '';
    const responsePaymentType = "pe"
    const responseHybrisPaymentMethod = "bank transfer";

    const getHybrisPaymentDetails = (paymentMethods, paymentResponseDetails, fieldType) => {
        let paymentDetails = paymentMethods.filter((i) => i.fields?.value?.value?.toLowerCase() === paymentResponseDetails?.paymentMethodDetails?.hybrisProcessOrderServiceResponse?.[fieldType]?.toLowerCase());
        console.log('Matched--', fieldType);
        return paymentDetails;
    }
    
    const getEmiDescription = (paymentMethods, paymentResponseDetails) => {
        const installmentAmount = paymentResponseDetails?.paymentMethodDetails?.hybrisProcessOrderServiceResponse?.installmentAmount;
        const installmentTotalCount = paymentResponseDetails?.paymentMethodDetails?.hybrisProcessOrderServiceResponse?.installmentTotalCount;
        const installmentDescriptions = !!installmentAmount && !!installmentTotalCount ? true : false;
        const emiDescriptionValue = installmentDescriptions && getHybrisPaymentDetails(paymentMethods, paymentMethodDetailsResponse, HYBRISPAYMENT_ATTRIBUTE.ACCOUNTTYPE);
        return emiDescriptionValue
    }

    if (
        responsePaymentType === INTERNAL_TOKEN.PENAVIGATION.toLowerCase() ||
        responsePaymentType === INTERNAL_TOKEN.CC2C2P.toLowerCase() ||
        responsePaymentType === INTERNAL_TOKEN.CYBERSOURCE.toLowerCase()
    )
    {
        if (
        responseHybrisPaymentMethod === ORDER_PAYMENT_MODE.PE_Boleto.toLowerCase() ||
        responseHybrisPaymentMethod === ORDER_PAYMENT_MODE.PE_FinanceOption.toLowerCase() ||
        responseHybrisPaymentMethod === ORDER_PAYMENT_MODE.PE_VirtualAccount.toLowerCase() ||
        responseHybrisPaymentMethod === ORDER_PAYMENT_MODE.PE_SepaDirectDebit.toLowerCase() ||
        responseHybrisPaymentMethod === ORDER_PAYMENT_MODE.PE_Klarna.toLowerCase()
        )
        {
          paymentDetailsValue = getHybrisPaymentDetails(paymentMethods, paymentMethodDetailsResponse, HYBRISPAYMENT_ATTRIBUTE.PAYMENTMETHOD);
          paymentMethodDetailsResponse.paymentMethodDetails.paymentMethodDisplayText = paymentDetailsValue?.length ? paymentDetailsValue?.[0]?.fields?.title?.value : paymentMethodDetailsResponse.paymentMethodDetails?.hybrisProcessOrderServiceResponse?.paymentMethod;
        }
        else {
            if (!!paymentMethodDetailsResponse.paymentMethodDetails?.hybrisProcessOrderServiceResponse?.accountType?.trim()){
                console.log('if');
                accountOrPaymentType = HYBRISPAYMENT_ATTRIBUTE.ACCOUNTTYPE;
                paymentDetailsValue =  getHybrisPaymentDetails(paymentMethods, paymentMethodDetailsResponse, HYBRISPAYMENT_ATTRIBUTE.ACCOUNTTYPE);
            }
            if (!paymentDetailsValue || paymentDetailsValue.length === 0){
                console.log('else if');
                accountOrPaymentType = HYBRISPAYMENT_ATTRIBUTE.PAYMENTMETHOD;
                paymentDetailsValue = getHybrisPaymentDetails(paymentMethods, paymentMethodDetailsResponse, HYBRISPAYMENT_ATTRIBUTE.PAYMENTMETHOD);
            }
            
            emiDescriptionField = getEmiDescription(paymentMethods, paymentMethodDetailsResponse);
            paymentMethodDetailsResponse.paymentMethodDetails.paymentMethodDisplayText = paymentDetailsValue?.length ? paymentDetailsValue?.[0]?.fields?.title?.value : paymentMethodDetailsResponse.paymentMethodDetails?.hybrisProcessOrderServiceResponse?.[accountOrPaymentType];
            paymentMethodDetailsResponse.paymentMethodDetails.paymentMethodDescription =  paymentDetailsValue?.length ? paymentDetailsValue?.[0]?.fields?.description?.value  : '';
            console.log('PE Title', paymentMethodDetailsResponse.paymentMethodDetails.paymentMethodDisplayText);
            paymentMethodDetailsResponse.paymentMethodDetails.paymentEmiDescription = emiDescriptionField?.length ? emiDescriptionField?.[0]?.fields?.paymentEmiDescription?.value : '';
        }
    }
    else{
        paymentDetailsValue = getHybrisPaymentDetails(paymentMethods, paymentMethodDetailsResponse, HYBRISPAYMENT_ATTRIBUTE.PAYMENTMETHOD);
        paymentMethodDetailsResponse.paymentMethodDetails.paymentMethodDisplayText = paymentDetailsValue?.length ? paymentDetailsValue?.[0]?.fields?.title?.value : paymentMethodDetailsResponse?.paymentMethodDetails?.hybrisProcessOrderServiceResponse?.paymentMethod;
        paymentMethodDetailsResponse.paymentMethodDetails.paymentMethodDescription = paymentDetailsValue?.length ? paymentDetailsValue?.[0]?.fields?.description?.value : '';
    }
    return paymentMethodDetailsResponse;
  }
  

const paymentMethodDetailsResponse = {
    "billingAddress": "<p style=\"margin-bottom: 0px;font-weight: 700;font-size: 18px;margin-top: 2px;\"> Asas Noah </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;font-weight: 700;margin-top: 0px;\">  </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;\"> Noah Tech </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\"> Arc Street </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\">  </p>\n            <p style=\"margin-bottom: 3px;font-size: 18px;margin-top: 0px;\"> 한국 111111 </p>",
    "shippingAddress": "<p style=\"margin-bottom: 0px;font-weight: 700;font-size: 18px;margin-top: 2px;\">   </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;font-weight: 700;margin-top: 0px;\"> Noah Tech </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;\"> Noah Tech </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\"> Arc Street </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\">  </p>\n            <p style=\"margin-bottom: 3px;font-size: 18px;margin-top: 0px;\"> 한국 111111 </p>",
    "contactInfo": "<p style=\"margin-bottom: 0px;font-weight: 700;font-size: 18px;margin-top: 2px; \"> Asas Noah </p>\n            <p style=\"margin-bottom:0px;font-size: 18px;\"> Noah Tech </p>\n            <p style=\"margin-bottom:0px;\"> krsanoahsarcrandomenail@gmail.com  </p>\n            <p style=\"margin-bottom:0px;\"> 98987654321 </p>",
    "paymentMethodDetails": {
        "paymentMethodDisplayValue": "",
        "paymentMethodDisplayText": "",
        "paymentMethodDescription": "",
        "installmentTotalCount": "",
        "installmentAmount": "",
        "paymentEmiDescription": "",
        "paymentType": "PE",
        "hybrisPaymentMethod": "Bank Transfer",
        "hybrisProcessOrderServiceResponse": {
            "order_id": "31147011",
            "accountType": "",
            "accountNumber": "",
            "purchaseOrderNumber": "",
            "salesOrderNumber": "",
            "paymentMethod": "Bank Transfer",
            "installmentTotalCount": "",
            "installmentAmount": "",
            "expirationDate": "",
            "virtualAccountExpirationTime": ""
        }
    }
}

const paymentMethods = [
    {
    "id": "d1592e92-e483-423b-ad29-57527375af36",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/manual-credit-card",
    "fields": {
    "id": "d1592e92-e483-423b-ad29-57527375af36",
    "name": "Manual Credit Card",
    "cardType": {
    "value": "Manual Credit Card"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "Manual Credit Card"
    },
    "title": {
    "value": "카드 결제"
    }
    }
    },
    {
    "id": "26c71598-87f8-4854-9a7d-f99bc14444fe",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/bank-transfer",
    "fields": {
    "id": "26c71598-87f8-4854-9a7d-f99bc14444fe",
    "name": "Bank Transfer",
    "cardType": {
    "value": "Wire Transfer"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": ""
    },
    "value": {
    "value": "Bank Transfer"
    },
    "title": {
    "value": "계좌이체"
    }
    }
    },
    {
    "id": "80088241-b74d-45d2-a20a-e38f7ba360d2",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/bc",
    "fields": {
    "id": "80088241-b74d-45d2-a20a-e38f7ba360d2",
    "name": "BC",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "BC카드"
    },
    "title": {
    "value": "BC카드"
    }
    }
    },
    {
    "id": "5b567383-41d1-4009-ae7c-e1258fcf593c",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/citibank",
    "fields": {
    "id": "5b567383-41d1-4009-ae7c-e1258fcf593c",
    "name": "CitiBank",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "씨티은행"
    },
    "title": {
    "value": "씨티은행"
    }
    }
    },
    {
    "id": "afee22b1-f641-412e-942f-699ce3982d46",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/hana",
    "fields": {
    "id": "afee22b1-f641-412e-942f-699ce3982d46",
    "name": "Hana",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "하나카드"
    },
    "title": {
    "value": "하나카드"
    }
    }
    },
    {
    "id": "690e916d-5b27-489e-a950-fe160fae75b2",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/hyundai",
    "fields": {
    "id": "690e916d-5b27-489e-a950-fe160fae75b2",
    "name": "Hyundai",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "현대카드"
    },
    "title": {
    "value": "현대카드"
    }
    }
    },
    {
    "id": "6fe60a45-69ea-43c9-9efc-2c3e761c5f0c",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/kb-kookmin",
    "fields": {
    "id": "6fe60a45-69ea-43c9-9efc-2c3e761c5f0c",
    "name": "KB Kookmin",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "KB국민카드"
    },
    "title": {
    "value": "KB국민카드"
    }
    }
    },
    {
    "id": "9b0a3014-52dc-4eee-8de0-650d004eaadd",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/lease-service",
    "fields": {
    "id": "9b0a3014-52dc-4eee-8de0-650d004eaadd",
    "name": "Lease Service",
    "cardType": {
    "value": "LEASE"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": ""
    },
    "value": {
    "value": "Lease Service"
    },
    "title": {
    "value": "리스 결제"
    }
    }
    },
    {
    "id": "d81bdf42-d291-426f-803d-c12a9c941f5d",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/lotte-eng",
    "fields": {
    "id": "d81bdf42-d291-426f-803d-c12a9c941f5d",
    "name": "Lotte eng",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "롯데카드"
    },
    "title": {
    "value": "롯데카드"
    }
    }
    },
    {
    "id": "b218da9e-ba7d-4935-992f-2c29779704bf",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/lotte-kor",
    "fields": {
    "id": "b218da9e-ba7d-4935-992f-2c29779704bf",
    "name": "Lotte kor",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "롯데카드"
    },
    "title": {
    "value": "롯데카드"
    }
    }
    },
    {
    "id": "cf54bfef-1331-425f-81a8-aae2705831fd",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/nh",
    "fields": {
    "id": "cf54bfef-1331-425f-81a8-aae2705831fd",
    "name": "NH",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "NH농협카드"
    },
    "title": {
    "value": "NH농협카드"
    }
    }
    },
    {
    "id": "f1f0b762-a30f-4673-838d-2d8aa8e00518",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/samsung",
    "fields": {
    "id": "f1f0b762-a30f-4673-838d-2d8aa8e00518",
    "name": "Samsung",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "삼성카드"
    },
    "title": {
    "value": "삼성카드"
    }
    }
    },
    {
    "id": "94a38d10-4fd0-49e4-9f0a-5e17384539bf",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/shinhan",
    "fields": {
    "id": "94a38d10-4fd0-49e4-9f0a-5e17384539bf",
    "name": "Shinhan",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "신한카드"
    },
    "title": {
    "value": "신한카드"
    }
    }
    },
    {
    "id": "d94476dc-baae-46ae-9fa7-a7c442bb647a",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/woori",
    "fields": {
    "id": "d94476dc-baae-46ae-9fa7-a7c442bb647a",
    "name": "Woori",
    "cardType": {
    "value": "Shinhan"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "우리카드"
    },
    "title": {
    "value": "우리카드"
    }
    }
    },
    {
    "id": "0321e5d0-b94b-4599-9512-f65cbf24e947",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/kakao-pay",
    "fields": {
    "id": "0321e5d0-b94b-4599-9512-f65cbf24e947",
    "name": "Kakao Pay",
    "cardType": {
    "value": "Kakao Pay"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "Kakaopay"
    },
    "title": {
    "value": "Kakao Pay"
    }
    }
    },
    {
    "id": "149b930e-392b-4002-93aa-df1d5dedf030",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/naver-pay",
    "fields": {
    "id": "149b930e-392b-4002-93aa-df1d5dedf030",
    "name": "Naver Pay",
    "cardType": {
    "value": ""
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": "카드결제 ({installmentTotalCount} 개월)"
    },
    "value": {
    "value": "Naverpay"
    },
    "title": {
    "value": "Naver Pay"
    }
    }
    },
    {
    "id": "59013036-c3de-4429-88c5-33b6d23a8d07",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/virtual-bank-transfer",
    "fields": {
    "id": "59013036-c3de-4429-88c5-33b6d23a8d07",
    "name": "Virtual Bank Transfer",
    "cardType": {
    "value": "VIRTUAL_ACCOUNT"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": ""
    },
    "value": {
    "value": "Virtual_Account"
    },
    "title": {
    "value": "가상 계좌 이체"
    }
    }
    }
    ]

const paymentMethodDetailsResponseUS ={"billingAddress": " <p style=\"margin-bottom: 0px;font-weight: 700;font-size: 18px;margin-top: 2px; \"> Asas Noah </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\"> 1683 Arcade St </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\">  </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\"> Saint Paul , Minnesota 55109 </p>",
"shippingAddress": " <p style=\"margin-bottom: 0px;font-weight: 700;font-size: 18px;margin-top: 2px; \"> Asas Noah </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\"> 1683 Arcade St </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\">  </p>\n            <p style=\"margin-bottom: 0px;font-size: 18px;margin-top: 0px;\"> Saint Paul , Minnesota 55109 </p>",
"contactInfo": "<p style=\"margin-bottom: 0px;font-weight: 700;font-size: 18px;margin-top: 2px; \"> Asas Noah </p><p style=\"margin-bottom:0px;font-size: 18px;margin-top: 0px;\"> Noah Tech </p>\n            <p style=\"margin-bottom:0px;font-size: 18px;margin-top: 0px;\"> noahsarcrandomenail@gmail.com </p><p style=\"margin-bottom:0px;font-size: 18px;margin-top: 0px;\"> (121) 212-1212 </p>",
"paymentMethodDetails": {
    "paymentMethodDisplayValue": "****1111",
    "paymentMethodDisplayText": "",
    "paymentMethodDescription": "",
    "installmentTotalCount": "",
    "installmentAmount": "",
    "paymentEmiDescription": "",
    "paymentType": "PE",
    "hybrisPaymentMethod": "Bank Transfer",
    "hybrisProcessOrderServiceResponse": {
        "order_id": "31147008",
        "accountType": "Business - checking",
        "accountNumber": "****1111",
        "purchaseOrderNumber": "",
        "salesOrderNumber": "",
        "paymentMethod": "Bank Transfer",
        "installmentTotalCount": "",
        "installmentAmount": "",
        "expirationDate": "",
        "virtualAccountExpirationTime": ""
    }
}};
const paymentMethodsUS =  [
    {
    "id": "0d84dcdf-0be6-43a9-abbc-fbb1352e4681",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/amex",
    "fields": {
    "id": "0d84dcdf-0be6-43a9-abbc-fbb1352e4681",
    "name": "amex",
    "value": {
    "value": "amex"
    },
    "title": {
    "value": "American Express"
    }
    }
    },
    {
    "id": "9f0692f8-4b2f-4ad6-9d9e-31e9ca926d9e",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/checking",
    "fields": {
    "id": "9f0692f8-4b2f-4ad6-9d9e-31e9ca926d9e",
    "name": "checking",
    "value": {
    "value": "checking"
    },
    "title": {
    "value": "Checking"
    }
    }
    },
    {
    "id": "cea7aa40-b4cb-4d3f-bc85-c9fa2af7875d",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/corporate_checking",
    "fields": {
    "id": "cea7aa40-b4cb-4d3f-bc85-c9fa2af7875d",
    "name": "corporate_checking",
    "value": {
    "value": "corporate_checking"
    },
    "title": {
    "value": "Corporate Checking"
    }
    }
    },
    {
    "id": "a35337c4-4740-4cca-a8ba-e26f6f4c54e7",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/master",
    "fields": {
    "id": "a35337c4-4740-4cca-a8ba-e26f6f4c54e7",
    "name": "master",
    "value": {
    "value": "master"
    },
    "title": {
    "value": "Mastercard"
    }
    }
    },
    {
    "id": "1a954314-4a0f-4391-ba1d-720c903631b3",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/purchase-order",
    "fields": {
    "id": "1a954314-4a0f-4391-ba1d-720c903631b3",
    "name": "purchase order",
    "value": {
    "value": "purchase order"
    },
    "title": {
    "value": "Purchase Order"
    }
    }
    },
    {
    "id": "4dd2a492-d8c5-40e8-bad5-8a45ce4e70f6",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/savings",
    "fields": {
    "id": "4dd2a492-d8c5-40e8-bad5-8a45ce4e70f6",
    "name": "savings",
    "value": {
    "value": "savings"
    },
    "title": {
    "value": "Savings"
    }
    }
    },
    {
    "id": "df7025dd-86e7-4922-9144-01c4aa274b61",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/visa",
    "fields": {
    "id": "df7025dd-86e7-4922-9144-01c4aa274b61",
    "name": "visa",
    "value": {
    "value": "visa"
    },
    "title": {
    "value": "Visa"
    }
    }
    },
    {
    "id": "df27e4b8-4d79-4908-b89b-7bcc5833501b",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/amex-card",
    "fields": {
    "id": "df27e4b8-4d79-4908-b89b-7bcc5833501b",
    "name": "Amex card",
    "cardType": {
    "value": "amex"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": ""
    },
    "value": {
    "value": "American Express"
    },
    "title": {
    "value": "American Express"
    }
    }
    },
    {
    "id": "9210a06e-664f-4ed3-9ec5-101593d533de",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/master-card",
    "fields": {
    "id": "9210a06e-664f-4ed3-9ec5-101593d533de",
    "name": "Master Card",
    "cardType": {
    "value": "master"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": ""
    },
    "value": {
    "value": "Mastercard"
    },
    "title": {
    "value": "Mastercard"
    }
    }
    },
    {
    "id": "7b7f4402-cb1b-42b7-9137-22dfcc0dbcd7",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/visa-card",
    "fields": {
    "id": "7b7f4402-cb1b-42b7-9137-22dfcc0dbcd7",
    "name": "Visa Card",
    "cardType": {
    "value": "visa"
    },
    "paymentGatewayCardCode": {
    "value": ""
    },
    "description": {
    "value": ""
    },
    "paymentEmiDescription": {
    "value": ""
    },
    "value": {
    "value": "Visa"
    },
    "title": {
    "value": "Visa"
    }
    }
    },
    {
    "id": "e6d7fd8f-577a-41ec-b55d-488ed45d1003",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/affirm",
    "fields": {
    "id": "e6d7fd8f-577a-41ec-b55d-488ed45d1003",
    "name": "Affirm",
    "value": {
    "value": "Affirm"
    },
    "title": {
    "value": "Affirm"
    }
    }
    },
    {
    "id": "9bf36add-1e47-4001-a3ba-1e7f2315fe31",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/sales-order",
    "fields": {
    "id": "9bf36add-1e47-4001-a3ba-1e7f2315fe31",
    "name": "sales order",
    "value": {
    "value": "sales order"
    },
    "title": {
    "value": "Sales Order"
    }
    }
    },
    {
    "id": "8aa63087-f6a7-4fcc-8a0d-e769ef9f3eff",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/business---checking",
    "fields": {
    "id": "8aa63087-f6a7-4fcc-8a0d-e769ef9f3eff",
    "name": "Business - checking",
    "value": {
    "value": "Business - checking"
    },
    "title": {
    "value": "Business - checking"
    }
    }
    },
    {
    "id": "15003f19-3649-4ca0-87f0-0dae22e3b2a1",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/business---saving",
    "fields": {
    "id": "15003f19-3649-4ca0-87f0-0dae22e3b2a1",
    "name": "Business - saving",
    "value": {
    "value": "Business - saving"
    },
    "title": {
    "value": "Business - saving"
    }
    }
    },
    {
    "id": "df722d86-2be9-4df0-9ceb-d24fc774eb6d",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/business---corporate-checking",
    "fields": {
    "id": "df722d86-2be9-4df0-9ceb-d24fc774eb6d",
    "name": "Business - corporate checking",
    "value": {
    "value": "Business - corporate checking"
    },
    "title": {
    "value": "Business - corporate checking"
    }
    }
    },
    {
    "id": "faf081ad-a248-45ab-ad59-ff0c4967ce39",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/personal---checking",
    "fields": {
    "id": "faf081ad-a248-45ab-ad59-ff0c4967ce39",
    "name": "Personal - checking",
    "value": {
    "value": "Personal - checking"
    },
    "title": {
    "value": "Personal - checking"
    }
    }
    },
    {
    "id": "3b178f09-256a-4fc4-8abd-891dc6f9e942",
    "isAvailableInPackage": "False",
    "itemUrl": "/data/commerce-order-confirmation/payment-methods/personal---saving",
    "fields": {
    "id": "3b178f09-256a-4fc4-8abd-891dc6f9e942",
    "name": "Personal - saving",
    "value": {
    "value": "Personal - saving"
    },
    "title": {
    "value": "Personal - saving"
    }
    }
    }
    ];
  const dataKR = getPaymentDetails(paymentMethodDetailsResponse, paymentMethods);
//   const dataUS = getPaymentDetails(paymentMethodDetailsResponseUS, paymentMethodsUS);



