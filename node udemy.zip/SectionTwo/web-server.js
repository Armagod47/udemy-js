const http = require('http');
const url = require('url');
const fs = require('fs');
const slugify = require('slugify');
// const replaceTemplate = require('./modules/replaceTemplates');


//So that read doesn't get executed every /api request
const data = fs.readFileSync(`${__dirname}/dev-data/data.json`, 'utf-8');
const dataObj = JSON.parse(data);

const templateOverview = fs.readFileSync(`${__dirname}/templates/overview.html`, 'utf-8');
const templateProduct = fs.readFileSync(`${__dirname}/templates/product.html`, 'utf-8');
const templateCard = fs.readFileSync(`${__dirname}/templates/card.html`, 'utf-8');

//Slugify : to rename suburl part to meaningful string
const slugs = dataObj.map(el => slugify(el.productName, {lower: true}));
console.log(slugs);

const replaceTemplate = (temp, product) => {
    let output = temp.replace(/{%PRODUCTNAME%}/g, product.productName);
    output = output.replace(/{%IMAGE%}/g, product.image);
    output = output.replace(/{%PRICE%}/g, product.price);
    output = output.replace(/{%FROM%}/g, product.from);
    output = output.replace(/{%NUTRIENTS%}/g, product.nutrients);
    output = output.replace(/{%QUANTITY%}/g, product.quantity);
    output = output.replace(/{%DESCRIPTION%}/g, product.description);
    output = output.replace(/{%ID%}/g, product.id);

    if(!product.organic){
    output = output.replace(/{%NOT_ORGANIC%}/g, 'not-organic');
    }

    return output;
};

const server = http.createServer((req, res) => {
    //Routing
    // const pathname = req.url;
    const {query, pathname} = url.parse(req.url, true);

    //Overview
    if(pathname === '/' || pathname === '/overview'){
        res.writeHead(200, {'Content-type' : 'text/html'});
        const cardsHtml = dataObj.map(card => replaceTemplate(templateCard, card)).join('');
        const overviewHtml = templateOverview.replace('{%PRODUCT_CARDS%}' , cardsHtml);
        res.end(overviewHtml);
    }

    //Product
    else if(pathname === '/product'){
        //Retrieving element based on query string
        const product = dataObj[query.id];
        const productHtml = replaceTemplate(templateProduct, product);
        res.end(productHtml);
    }

    //API
    else if(pathname === '/api'){
            res.writeHead(200, {
                'Content-type' : 'application/json',
            });
            res.end(data);
        }
    
    //Not Found
    else {
        res.writeHead(404, {
            //headers need to be send before response
            'Content-type' : 'text/html',
            'my-own-header' : 'hello-world', //custom header
        });
        res.end('<h1>Page Not Found!!!</h1>');
    }
})

server.listen(3030, 'localhost', () => {
    console.log('Listening to request on port 3030');
})