const welcome = "Hello World!!!";
// console.log(welcome);



//----------------------------------------------------------------------
//Blocking / Synchronous
//Read File System
const fileSystem = require('fs');
const textFromFile = fileSystem.readFileSync('./file.txt', 'utf-8');
// console.log(textFromFile);

//Write File System
const textWriter = `Writing from Node JS with dynamic value: ${textFromFile} in ${Date.now()}`;
// fileSystem.writeFileSync('./output.txt', textWriter);
// console.log('File has been written!!!');

//----------------------------------------------------------------------

//Non Blocking / ASynchronous
const fileSystemAsync = require('fs');
fileSystemAsync.readFile('./texts/Async.txt', 'utf-8' , (err, data1) => {
    fileSystemAsync.readFile(`./texts/${data1}.txt`, 'utf-8' , (err, data2) => {
        console.log(data2);

        fileSystemAsync.writeFile('./texts/AsyncWrite.txt', `Written From Code --- \n${data1} \n ${data2}` ,'utf-8', err => {
            console.log('File has been written....');
        })
    });
});
console.log('This Log will be read , before Async');